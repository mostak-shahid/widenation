<?php

defined('_JEXEC') or die('Restricted access');

$settingsParams = new UniteGallerySettingsUG();
$settingsParams->loadXMLFile(GlobalsUG::$pathHelpersSettings."advancedtab_params.xml");


?>