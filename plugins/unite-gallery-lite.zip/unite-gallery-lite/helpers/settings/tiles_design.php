<?php

defined('_JEXEC') or die('Restricted access');

$settings = new UniteGallerySettingsUG();
$settings->loadXMLFile(GlobalsUG::$pathHelpersSettings."tiles_design.xml");



?>