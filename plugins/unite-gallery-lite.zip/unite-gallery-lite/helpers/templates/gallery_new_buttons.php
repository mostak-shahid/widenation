<?php

defined('_JEXEC') or die('Restricted access');

?>	
			<div class="vert_sap40"></div>
	
			<a id="button_save_gallery" class='unite-button-primary' href='javascript:void(0)' ><?php _e("Create Gallery",UNITEGALLERY_TEXTDOMAIN); ?></a>
			
			<span class="hor_sap"></span>
			
			<a class='unite-button-secondary' href='<?php echo HelperGalleryUG::getUrlViewGalleriesList() ?>' ><?php _e("Close",UNITEGALLERY_TEXTDOMAIN); ?></a>

			<div class="vert_sap20"></div>
			
			<div id="error_message_settings" class="unite_error_message" style="display:none"></div>
					