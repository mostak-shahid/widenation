<?php

defined('_JEXEC') or die('Restricted access');

// require $headerTitle variable

require HelperUG::getPathTemplate("header");

?>