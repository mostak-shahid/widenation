<?php


defined('_JEXEC') or die('Restricted access');


	require_once GlobalsUG::$pathHelpersClasses."include_classes.php";

	require_once $pathGallery."inc_php/output.class.php";
?>